<!DOCTYPE html>
<html lang="en">



<?php
$total = 0;

if (isset($_GET['Supreme'])){
$Supreme = $_GET['Supreme'];
$supremePrice = $_GET['supremePrice'];
    echo $Supreme;
    echo ": &nbsp; ₱";   
    echo  number_format($supremePrice,2);
    echo "<p>";
    $total = $total + $supremePrice;
    
}




if (isset($_GET['Champ'])){
$Champ = $_GET['Champ'];
$champPrice = $_GET['champPrice'];
    echo $Champ;
    echo ": &nbsp; ₱"; 
    echo  number_format($champPrice,2);
    echo "<p>";
    $total = $total + $champPrice;
}



if (isset($_GET['Meaty_Overload'])){
$Meaty_Overload = $_GET['Meaty_Overload'];
$meatyPrice = $_GET['meatyPrice'];
    echo $Meaty_Overload;
    echo ": &nbsp; ₱";
    echo  number_format($meatyPrice,2);
    echo "<p>";
    $total = $total + $meatyPrice;
}

 

if (isset($_GET['Hawaiian'])){
$Hawaiian = $_GET['Hawaiian'];
$hawaiianPrice = $_GET['hawaiianPrice'];
    echo $Hawaiian;
    echo ": &nbsp; ₱"; 
    echo  number_format($hawaiianPrice,2);
    echo "<p>";
    $total = $total + $hawaiianPrice;
}



if (isset($_GET['Double_Cheese'])){
$Double_Cheese = $_GET['Double_Cheese'];
$doublecheesePrice = $_GET['doublecheesePrice'];
    echo $Double_Cheese;
    echo ": &nbsp; ₱"; 
    echo  number_format($doublecheesePrice,2);
    echo "<p>";
    $total = $total + $doublecheesePrice;
}




if (isset($_GET['Veggie'])){
$Veggie = $_GET['Veggie'];
$veggiePrice = $_GET['veggiePrice'];
    echo $Veggie;
    echo ": &nbsp; ₱";
    echo  number_format($veggiePrice,2);
    echo "<p>";
    $total = $total + $veggiePrice;
}




if (isset($_GET['buffalo'])){
$buffalo = $_GET['buffalo'];
$buffaloPrice = $_GET['buffaloPrice'];
    echo $buffalo;
    echo ": &nbsp; ₱"; 
    echo  number_format($buffaloPrice,2);
    echo "<p>";
    $total = $total + $buffaloPrice;
}



if (isset($_GET['cheesetoastie'])){
$cheesetoastie = $_GET['cheesetoastie'];
$cheesetoastiePrice = $_GET['cheesetoastiePrice'];
    echo $cheesetoastie;
    echo ": &nbsp; ₱"; 
    echo  number_format($cheesetoastiePrice,2);
    echo "<p>";
    $total = $total + $cheesetoastiePrice;
}




if (isset($_GET['garlicshrimp'])){
$garlicshrimp = $_GET['garlicshrimp'];
$garlicshrimpPrice = $_GET['garlicshrimpPrice'];
    echo $garlicshrimp;
    echo ": &nbsp; ₱"; 
    echo  number_format($garlicshrimpPrice,2);
    echo "<p>";
    $total = $total + $garlicshrimpPrice;
}




if (isset($_GET['familyfries'])){
$familyfries = $_GET['familyfries'];
$familyfriesPrice = $_GET['familyfriesPrice'];
    echo $familyfries;
    echo ": &nbsp; ₱"; 
    echo  number_format($familyfriesPrice,2);
    echo "<p>";
    $total = $total + $familyfriesPrice;
}




if (isset($_GET['hungarianhotdog'])){
$hungarianhotdog = $_GET['hungarianhotdog'];
$hungarianhotdogPrice = $_GET['hungarianhotdogPrice'];
    echo $hungarianhotdog;
    echo ": &nbsp; ₱"; 
    echo  number_format($hungarianhotdogPrice,2);
    echo "<p>";
    $total = $total + $hungarianhotdogPrice;
}




if (isset($_GET['chocoespresso'])){
$chocoespresso = $_GET['chocoespresso'];
$chocoespressoPrice = $_GET['chocoespressoPrice'];
    echo $chocoespresso;
    echo ": &nbsp; ₱"; 
    echo  number_format($chocoespressoPrice,2);
    echo "<p>";
    $total = $total + $chocoespressoPrice;
}



if (isset($_GET['coldbrew'])){
$coldbrew = $_GET['coldbrew'];
$coldbrewPrice = $_GET['coldbrewPrice'];
    echo $coldbrew;
    echo ": &nbsp; ₱"; 
    echo  number_format($coldbrewPrice,2);
    echo "<p>";
    $total = $total + $coldbrewPrice;
}




if (isset($_GET['darkfrapp'])){
$darkfrapp = $_GET['darkfrapp'];
$darkfrappPrice = $_GET['darkfrappPrice'];
    echo $darkfrapp;
    echo ": &nbsp; ₱"; 
    echo  number_format($darkfrappPrice,2);
    echo "<p>";
    $total = $total + $darkfrappPrice;
}



if (isset($_GET['strawberrysmoothie'])){
$strawberrysmoothie = $_GET['strawberrysmoothie'];
$strawberrysmoothiePrice = $_GET['strawberrysmoothiePrice'];
    echo $strawberrysmoothie;
    echo ": &nbsp; ₱"; 
    echo  number_format($strawberrysmoothiePrice,2);
    echo "<p>";
    $total = $total + $strawberrysmoothiePrice;
}



if (isset($_GET['vanillemilk'])){
$vanillemilk = $_GET['vanillemilk'];
$vanillemilkPrice = $_GET['vanillemilkPrice'];
    echo $vanillemilk;
    echo ": &nbsp; ₱"; 
    echo  number_format($vanillemilkPrice,2);
    echo "<p>";
    $total = $total + $vanillemilkPrice;
}



if (isset($_GET['matchatea'])){
$matchatea = $_GET['matchatea'];
$matchateaPrice = $_GET['matchateaPrice'];
    echo $matchatea;
    echo ": &nbsp; ₱"; 
    echo  number_format($matchateaPrice,2);
    echo "<p>";
    $total = $total + $matchateaPrice;
    
}
?>
<?php
if( $total <= 0){
    echo "NO ORDER <br>";
}
else{
    echo "Total: &nbsp; ₱";
    echo number_format($total,2);
    echo "<br>";
}

    echo "Enter cash: <br>"
?>

<div>
<input type="text" name="cash" size="15" value="<?php echo $total?>" id="cash">

<input type="button"  value="COMPUTE" onclick="FUNCTION(this.value)">
<input type="button" value="CLEAR" onclick="FUNCTION(this.value)">
    <div id="computation">

    </div>

    <div id="menu" style="display:none">
       <a href= "OrderPage3.php" id="OrderAgain" >Order Again</a>
    </div>
</div>

<script>

 function OrderAgain(){
    
 }

 function FUNCTION(action){
    if(action == "COMPUTE"){
        var cash = document.getElementById("cash").value;
        var total = <?php echo $total ?>;



        var computation = cash - total;
        if(computation > 0 ){
            document.getElementById("computation").innerHTML = "Change: ₱" +computation  + " Thank you mwah";
            var menu = document.getElementById("menu");
            menu.style.display = "block";
        }
        else if( computation == 0){
            document.getElementById("computation").innerHTML = "Thank you mwah ";
            var menu = document.getElementById("menu");
            menu.style.display = "block";
        }
        else{
            var computation = total - cash;
            console.log(computation);
            document.getElementById("computation").innerHTML = "Inssufisyent balance :₱ "+computation;
        }
        
    }
    else if(action == "CLEAR"){
        document.getElementById("cash").value = "";
    }

 }

</script>

