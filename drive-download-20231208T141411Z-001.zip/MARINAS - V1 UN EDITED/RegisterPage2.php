<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel= "stylesheet" href = "registerStyle.css"> 
    <title>Register</title>
       
</head>
<body>
    <div class="container">
        <div class="image"></div>
        <div class="regist-form">
       
            <div class="header">     
				<h1>Malabanan Cafe</h1>
				<img src="caf3.png">	
            </div>
			
			
			<center><h1>Registration</h1></center> <br>
            <?php
        if (isset ($_POST ["submit"])) {
            $fname = $_POST["fname"];
            $lname = $_POST["lname"];
            $username = $_POST["username"];
            $password = $_POST["password"];
            $pnumber = $_POST["pnumber"];
            $address = $_POST["address"];
            $zipcode = $_POST["zipcode"];
            $gender = $_POST["gender"];

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);


            $errors = array();
           
            if (empty($fname) OR empty($lname) OR empty($username) OR empty($password) OR empty($pnumber) OR empty($address) OR empty($zipcode) OR empty($gender)) {
                array_push($errors, "All Required");
            }
           

            if (strlen($password)<8){
                array_push($errors, "Password must be at least 8 characters long");
            }
            
            require_once "db_con.php";
            $sql = "SELECT * FROM tb_register WHERE username = '$username'" ;
            $result = mysqli_query($conn, $sql);
            $rowCount = mysqli_num_rows($result);
            if ($rowCount>0) {
                array_push($errors, "Username already exist!");
            }

            if (count($errors)>0) {
                foreach ($errors as $error){
                    echo "<div class = 'alert alert-danger'> $error </div>";
                }
            }else {
                
                $sql = "INSERT INTO tb_register (firstname, lastname, username, password, pnumber, address, zipcode, gender)  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";/*VALUES ($fname,$lname,$username,$password,$pnumber,$address,$zipcode,$gender)"*/
                $stmt = mysqli_stmt_init($conn);
                $prepareStmt = mysqli_stmt_prepare($stmt, $sql);
                if ($prepareStmt){
                    mysqli_stmt_bind_param($stmt,"ssssssss", $fname, $lname, $username, $passwordHash, $pnumber, $address, $zipcode, $gender);
                    mysqli_stmt_execute($stmt);
                    echo "<div class ='alert1 alert-success'> You are registered. </div>";

                }else {
                    die ("may mali");
                }
            }

        }    
        ?>
            <h2>User Details</h2>
            <form  action="RegisterPage2.php" method="post">

            
			
				
            <div class="forname">				
				<div class="name">
					<label for= "fname">First Name</label>
					<input type="text"  placeholder="Enter First name" id="fname" name="fname" maxlength="15" required>
				</div>
				<div class="name">
					<label for="lname">Last Name</label>
					<input type="text"  placeholder="Enter Last name" id="lname" name="lname" maxlength="15" required> 
				</div> 
			</div>	
								
				<div class="form-group">
                    <br><label for="username">Username</label> 
                    <input type="text" placeholder="Enter Username" id="username" name="username" maxlength="15" required>
                </div>
				
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" placeholder="Enter Password" id="password" name="password" maxlength="20" required>
				</div>
					
			
				<div class="form-group">
                    <label for="pnumber">Phone Number</label>
                    <input type="text" placeholder="1111-222-3333" id="pnumber" name="pnumber" maxlength="11"  required>	
                </div>
				

				<div class="form-group">
                    <label for="adress">Address</label> 
                    <input type="text" placeholder="Enter Address" id="address" name="address" maxlength="50" required>	
                </div>
				
				
				<div class="form-group">
                  	<label for="zipcode">Zip Code</label>
                    <input type="text" placeholder="1001" id="zipcode" name="zipcode" maxlength="4" required>	
                </div>
				
				
				<div class="form-group">
                    <label for="gender"> Gender </label>
					<input type="radio" id="male" name="gender" value="Male" for="male" required>Male
					<input type="radio" id="female" name="gender" value="Female" for="female" required>Female
				</div>	
                <br>
				
                <hr class="hrSize">
                <input type="checkbox" id="terms" oninvalid="this.setCustomValidity('Read Terms and Conditions.')" oninput="setCustomValidity('')" required >

                I agree to these <a href="terms1.php" 
                target="popup" onclick="window.open('terms1.php','popup','width=600,height=600'); return false;">
                Terms and Conditions </a>
                        
				


               
	
				
				<div class ="UsrButton">
                <div class="form-group">
                    <br><input type="submit" value="Register" name="submit">
				</div>	
				
				<div class="form-group">
                    <br><input type="reset" value="Clear">				
                </div>
				
				</div>
            </form>
			
			<form action="LoginPage1.php" method="post">
				<div class="Back2Log">
                    <input type="submit" value="Back to Login">
				</div>	
			</form>
			
        </div>
    </div>
    </div>    
</body>
</html>



