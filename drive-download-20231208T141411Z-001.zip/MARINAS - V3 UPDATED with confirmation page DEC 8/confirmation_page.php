 <?php 
    session_start();

    if(empty($_SESSION['userName'])){
        ?>
            <script>
                alert("ERROR!");
                window.location.href = "LoginPage1.php";
            </script>
        <?php
    }

function generateRandomCode() {
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '#';

    for ($i = 0; $i < 2; $i++) {
        $code .= $letters[rand(0, strlen($letters) - 1)];
    }

    $code .= rand(1000, 9999);

    return $code;
}

$randomCode = generateRandomCode();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
</head>
<body>

<div id="popup">
    <h1>Order Confirmation</h1>
    <p>Thank you for your order! Your order has been successfully placed.</p>
    <p>Your order code is: <strong><?php echo $randomCode; ?></strong></p>
    <p>You can go to the nearest branch and take your order.</p>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        showPopup();
    });

    function showPopup() {
        document.getElementById("popup").style.display = "block";
    }

</script>

</body>
</html>
