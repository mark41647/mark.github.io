<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel= "stylesheet" href = "loginStyle.css"> 
    <title>Login Page</title>


		

</head>
<body>

    <div class="container">
        <div class="image"></div>
        <div class="login-form">
            <div class="header">
                
                <h1>Malabanan Cafe</h1>
				<img src="caf3.png">
            </div>
            <?php 
                session_start();
                
                if (isset ($_POST["login"])) {
                    $username = $_POST ["username"];
                    $password = $_POST ["password"];

                        require_once "db_con.php";
                        $sql = "SELECT * FROM tb_register WHERE username = '$username'";
                        $result= mysqli_query($conn, $sql);
                        $tb_register = mysqli_fetch_array($result, MYSQLI_ASSOC);
                            
                            if ($tb_register) {
                                if (password_verify($password, $tb_register["password"])) {

                                    $_SESSION["userName"] = $username;
                                    header ("Location: OrderPage3.php");
                                    die();
                                }else{
                                    echo "<div class = 'alert alert-danger'> Incorrect Password. </div>";
                                }
                                
                            }else {
                                echo "<div class = 'alert alert-danger'> Username do not exist. </div>";
                            }

                    }
                    ?>


            <h2>Login</h2>
			
            <form action="LoginPage1.php" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" placeholder="Enter Username" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" placeholder="Enter Password" id="password" name="password" required>
                </div>
				
				
				<div class ="UsrButton">
					<div class="form-group login">
						<input type="submit" value="Log-in" name = "login" class= "btn btn-primary" >
					</div>
					
            </form>
			
			<form action="RegisterPage2.php" method="post">
				<div class="regis">	
					<input type="submit" value="Register">
				</div>
			</form>
			
				</div>
        </div>	
    </div>
</body>
</html>
