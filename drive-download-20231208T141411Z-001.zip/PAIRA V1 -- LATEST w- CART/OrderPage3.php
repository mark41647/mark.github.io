<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtmll/DTD/xhtmll-transitional.dtd">
<html lang="en">    
<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="orderStyle.css">
    <title>Malabanan Cafe</title>
    <link rel="icon" href="caf3.png">
</head>
<body>
    <div id="Order">  

    </div>
    <header>
        <nav>
            <div class="header">
                <img src="caf3.png" class = 'logo'>
                <p class = "title1" id="Top"><a href="#Title1">Malabanan Cafe</a></p>
            </div>

            <div class="user">
                <a href="#"><?php echo $_SESSION['userName']; ?></a>
                <a href="Cartpage4.php">Cart</a>      

           
                <?php
if (isset($_GET['logout'])) {
    $_SESSION = array();

    session_destroy();
    header("Location: LoginPage1.php");
    exit();
}
?>
<?php
    if (isset($_SESSION['userName'])) {
        echo "<a href='?logout=1'>Logout</a>";
    } else {
        echo "<p>You are not logged in.</p>";
    }
    ?>

            </div>
        </nav>
       
    </header>
    <div class="banner">
            <!-- Placeholder image -->
            <img src="banner4.jpg" alt="Banner">
        </div>
    <div class="main-content">

    <nav class="menuBg"></nav>
       
        <nav class="menu">
        
        
            <ul>
                <li><a href="#Top"><img src="Up.png" style="width: 25px"></a></li>
                <li><h1 style="color: #fff"> Menu</h1></li>
                <hr style="color: #fff">
                <li><a href="#BurgersS">Burgers</a></li>
                <li><a href="#SnacksS">Snacks</a></li>
                <li><a href="#BeveragesS">Beverages</a></li>
                <br/>
                <li><a href="#Bot"><img src="Bot.png" style="width: 25px"></a></li>
                
            </ul>
        </nav>


        <div class="content">
            <form action="Cartpage4.php" method="GET">
            <!-- Content of the clicked menu will be displayed here -->
            <div class="BurgersSection">
                <h1 id="BurgersS" style="text-align: center;"> Burgers </h1>
                <hr class="hrSize">

                <div class="BurgCards">

                    <div class="food-card">
                        <img src="Burger1.jpg" alt="Burger">
                        <h3>Supreme</h3>
                        <input type="checkbox" name="Supreme" value="Supreme" >
                        Price: ₱                        
                        <?php
                        echo number_format( 114.00,2);
                        echo "<input type=hidden name=supremePrice value='114'>";
                        ?>                 
                    </div>  

                    <div class="food-card">
                        <img src="Burger4.jpg" alt="Burger">
                        <h3>Champ</h3>
                        <input type="checkbox" name="Champ" value="Champ" >
                        Price: ₱ 
                        <?php
                        echo number_format( 193.00,2);
                        echo "<input type=hidden name=champPrice value='193'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Burger5.jpg" alt="Burger">
                        <h3>Meaty Overload</h3>
                        <input type="checkbox" name="Meaty Overload" value="Meaty Overload" >
                        Price: ₱ 
                        <?php
                        echo number_format( 88.00,2);
                        echo "<input type=hidden name=meatyPrice value='88'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Burger3.jpg" alt="Burger">
                        <h3>Hawaiian</h3>
                        <input type="checkbox" name="Hawaiian" value="Hawaiian" >
                        Price: ₱
                        <?php
                        echo number_format(85.00,2);
                        echo "<input type=hidden name=hawaiianPrice value='85'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Burger6.jpg" alt="Burger">
                        <h3>Double Cheese</h3>
                        <input type="checkbox" name="Double Cheese" value="Double Cheese" >
                        Price: ₱ 
                        <?php
                        echo number_format(78.00,2);
                        echo "<input type=hidden name=doublecheesePrice value='78'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Burger2.jpg" alt="Burger">
                        <h3>Veggie Overload</h3>
                        <input type="checkbox" name="Veggie" value="Veggie Overload" >
                        Price: ₱ 
                        <?php
                        echo number_format(75.00,2);
                        echo "<input type=hidden name=veggiePrice value='75'>";
                        ?>  
                    </div>


                    <hr class="hrSize">

                </div>

                
            </div>
            <div class="SnacksSection">
                <h1  id="SnacksS" style="text-align: center;"> Snacks </h1>
                <hr class="hrSize">

                <div class="BurgCards">


                    <div class="food-card">
                        <img src="Snack1.jpg" alt="Burger">
                        <h3>Buffalo Wings</h3>
                        <input type="checkbox" name="buffalo" value="Buffalo Wings" >
                        Price: ₱
                        <?php
                        echo number_format(78.00,2);
                        echo "<input type=hidden name=buffaloPrice value='78'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Snack2.jpg" alt="Burger">
                        <h3>Cheese Toastie</h3>
                        <input type="checkbox" name="cheesetoastie" value="Cheese Toastie" >
                        Price: ₱ 
                        <?php
                        echo number_format(65.00,2);
                        echo "<input type=hidden name=cheesetoastiePrice value='65'>";
                        ?>  
                    </div>
                    
                    <div class="food-card">
                        <img src="Snack3.jpg" alt="Burger">
                        <h3>Garlic Shrimp</h3>
                        <input type="checkbox" name="garlicshrimp" value="Garlic Shrimp" >
                        Price: ₱ 
                        <?php
                        echo number_format(58.00,2);
                        echo "<input type=hidden name=garlicshrimpPrice value='58'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Snack4.jpg" alt="Burger">
                        <h3>Family Fries</h3>
                        <input type="checkbox" name="familyfries" value="Family Fries" >
                        Price: ₱ 
                        <?php
                        echo number_format(55.00,2);
                        echo "<input type=hidden name=familyfriesPrice value='55'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Snack5.jpg" alt="Burger">
                        <h3>Hungarian Hotdog</h3>
                        <input type="checkbox" name="hungarianhotdog" value="Hungarian Hotdog" >
                        Price: ₱ 
                        <?php
                        echo number_format(48.00,2);
                        echo "<input type=hidden name=hungarianhotdogPrice value='48'>";
                        ?>  
                    </div>
                   
                    
                    <hr class="hrSize">
                    
                    
                </div>    
            </div>

            <div class="DrinksSection">
                <h1  id="BeveragesS" style="text-align: center;"> Beverages </h1>
                <hr class="hrSize">

                <div class="BurgCards">
                    
                    <div class="food-card">
                        <img src="Drink1.jpg" alt="Burger">
                        <h3>Choco Espresso</h3>
                        <input type="checkbox" name="chocoespresso" value="Choco Espresso" >
                        Price: ₱ 
                        <?php
                        echo number_format(75.00,2);
                        echo "<input type=hidden name=chocoespressoPrice value='75'>";
                        ?>  
                    </div>

                    <div class="food-card">
                        <img src="Drink2.jpg" alt="Burger">
                        <h3>Cold Brew Caramel</h3>
                        <input type="checkbox" name="coldbrew" value="Cold Brew Caramel" >
                        Price: ₱    
                        <?php
                        echo number_format(75.00,2);
                        echo "<input type=hidden name=coldbrewPrice value='75'>";
                        ?> 
                    </div>

                    <div class="food-card">
                        <img src="Drink3.jpg" alt="Burger">
                        <h3>Dark Frappuccino</h3>
                        <input type="checkbox" name="darkfrapp" value="Dark Frappuccino" >
                        Price: ₱ 
                        <?php
                        echo number_format(70.00,2);
                        echo "<input type=hidden name=darkfrappPrice value='70'>";
                        ?> 
                    </div>

                    <div class="food-card">
                        <img src="Drink4.jpg" alt="Burger">
                        <h3>Strawberry Smoothie</h3>
                        <input type="checkbox" name="strawberrysmoothie" value="Strawberry Smoothie" >
                        Price: ₱ 
                        <?php
                        echo number_format(65.00,2);
                        echo "<input type=hidden name=strawberrysmoothiePrice value='65'>";
                        ?> 
                    </div>

                    <div class="food-card">
                        <img src="Drink5.jpg" alt="Burger">
                        <h3>Vanilla Milk Tea</h3>
                        <input type="checkbox" name="vanillemilk" value="Vanilla Milk Tea" >
                        Price: ₱ 
                        <?php
                        echo number_format(55.00,2);
                        echo "<input type=hidden name=vanillemilkPrice value='55'>";
                        ?> 
                    </div>

                    <div class="food-card">
                        <img src="Drink6.jpg" alt="Burger">
                        <h3>Matcha Tea Latte</h3>
                        <input type="checkbox" name="matchatea" value="Matcha Tea Latte" >
                        Price: ₱ 
                        <?php
                        echo number_format(58.00,2);
                        echo "<input type=hidden name=matchateaPrice value='58'>";
                        ?> 
                    </div>

                    
                    
                    
                    <hr class="hrSize">
                
                </div>    
            </div>

            <hr class="BotLine" id="Bot">

        
        </div>
        


    </div>


	<div class="cart">
		<div class="cart-info">
            <span id="cartTotal">Total quantity in the cart: 0 </span>
                <div class ="ViewOrderButton">
                    <button type="submit">Checkout</button>
                </div>
        </div>
    </div>
	
    </form>
</body>
</html>


<script>
document.addEventListener("DOMContentLoaded", function () {
    // Get all checkbox elements
    const checkboxes = document.querySelectorAll(".food-card input[type='checkbox']");
    const cartInfo = document.getElementById("cartTotal");

    let cartTotalQuantity = 0;

    // Loop through each checkbox element and attach event listeners
    checkboxes.forEach((checkbox) => {
        checkbox.addEventListener("change", function () {
            // Update the total quantity based on the checked state of the checkbox
            if (checkbox.checked) {
                cartTotalQuantity++;
            } else {
                cartTotalQuantity--;
            }

            updateCartInfo();
        });
    });

    // Function to update the cart info text
    function updateCartInfo() {
        cartInfo.textContent = `Total quantity in the cart: ${cartTotalQuantity}`;
    }
});
</script>


