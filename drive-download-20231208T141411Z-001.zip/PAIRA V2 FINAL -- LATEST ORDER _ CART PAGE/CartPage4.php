<!DOCTYPE html>
<html lang="en">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtmll/DTD/xhtmll-transitional.dtd">
<html lang="en">    
<head>
    <?php 
    session_start();

    if(empty($_SESSION['userName'])){
        ?>
            <script>
                alert("PLEASE LOG IN FIRST!");
                window.location.href = "LoginPage1.php";
            </script>
        <?php
    }
	?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CartStyle.css">
    <title>Malabanan Cafe</title>
    <link rel="icon" href="caf3.png">
</head>
<body>
    <div id="Order">  

    </div>
    <header>
        <nav>
            <div class="header">
                <img src="caf3.png" class = 'logo'>
                <p class = "title1" id="Top"><a href="#Title1">Malabanan Cafe</a></p>
            </div>

            <div class="user">
                <a href="#"><?php echo $_SESSION['userName']; ?></a>
                <a href="Cartpage4.php">Cart</a>      

           
<?php
if (isset($_GET['logout'])) {
    $_SESSION = array();

    session_destroy();
    header("Location: LoginPage1.php");
    exit();
}
?>
<?php
    if (isset($_SESSION['userName'])) {
        echo "<a href='?logout=1'>Logout</a>";
    } else {
        echo "<p>You are not logged in.</p>";
    }
    ?>

            </div>
        </nav>
       
    </header>
    <div class="banner">
            <!-- Placeholder image -->
            <img src="banner4.jpg" alt="Banner">
        </div>
		
		
		
		
	


<div class="main-content">


	<div class="CheckOutSection">
                <h1 id="CheckOutt" style="text-align: center;"> Checkout </h1>

	</div>	

 <hr class="hrSize">
	<div class="content">
	
	
		<h3>

		<?php
		$total = 0;
		$totalQuantity =0;


		
		
		if (isset($_GET['Supreme'])) {
		$Supreme = $_GET['Supreme'];
		$supremePrice = $_GET['supremePrice'];
		$supremeQuantity = $_GET['supremeQuantity'];
		$totalsupremePrice = $supremePrice * $supremeQuantity;
		echo '<div class="ItemContent">';
		echo '<div class="menu-item">' . $Supreme . '</div>';
		echo '<div class="menu-Quanty"> x' . $supremeQuantity . '</div>';
		echo '<div class="menu-price">₱' . number_format($supremePrice, 2) . '</div>';
		echo '</div>';
		$totalQuantity = $totalQuantity + $supremeQuantity;
		$total = $total + $totalsupremePrice;			
		}	
			
	
		if (isset($_GET['Champ'])){
			$Champ = $_GET['Champ'];
			$champPrice = $_GET['champPrice'];
			$champQuantity = $_GET['champQuantity'];
			$totalchampPrice = $champPrice * $champQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $Champ . '</div>';
			echo '<div class="menu-Quanty"> x' . $champQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($champPrice, 2) . '</div>';
			echo '</div>';	
			$totalQuantity = $totalQuantity + $champQuantity;
			$total = $total + ($champPrice * $champQuantity);
		}


		if (isset($_GET['Meaty_Overload'])){
			$Meaty_Overload = $_GET['Meaty_Overload'];
			$meatyPrice = $_GET['meatyPrice'];
			$meatyQuantity = $_GET['meatyQuantity'];
			$totalmeatyPrice = $meatyPrice * $meatyQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $Meaty_Overload . '</div>';
			echo '<div class="menu-Quanty"> x' . $meatyQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($meatyPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $meatyQuantity;
			$total = $total + ($meatyPrice * $meatyQuantity);
		}

		if (isset($_GET['Hawaiian'])){
			$Hawaiian = $_GET['Hawaiian'];
			$hawaiianPrice = $_GET['hawaiianPrice'];
			$hawaiianQuantity = $_GET['hawaiianQuantity'];
			$totalhawaiianPrice = $hawaiianPrice * $hawaiianQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $Hawaiian . '</div>';
			echo '<div class="menu-Quanty"> x' . $hawaiianQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($hawaiianPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $hawaiianQuantity;
			$total = $total + ($hawaiianPrice * $hawaiianQuantity);
		}

		if (isset($_GET['Double_Cheese'])){
			$Double_Cheese = $_GET['Double_Cheese'];
			$doublecheesePrice = $_GET['doublecheesePrice'];
			$doublecheeseQuantity = $_GET['doublecheeseQuantity'];
			$totaldoublecheesePrice = $doublecheesePrice * $doublecheeseQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $Double_Cheese . '</div>';
			echo '<div class="menu-Quanty"> x' . $doublecheeseQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($doublecheesePrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $doublecheeseQuantity;
			$total = $total + ($doublecheesePrice * $doublecheeseQuantity);
		}

		if (isset($_GET['Veggie_Overload'])){
			$Veggie = $_GET['Veggie_Overload'];
			$veggiePrice = $_GET['veggiePrice'];
			$veggieQuantity = $_GET['veggieQuantity'];
			$totalveggiePrice = $veggiePrice * $veggieQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $Veggie . '</div>';
			echo '<div class="menu-Quanty"> x' . $veggieQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($veggiePrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $veggieQuantity;
			$total = $total + ($veggiePrice * $veggieQuantity);
		}




		if (isset($_GET['buffalo'])){
			$buffalo = $_GET['buffalo'];
			$buffaloPrice = $_GET['buffaloPrice'];
			$buffaloQuantity = $_GET['buffaloQuantity'];
			$totalbuffaloPrice = $buffaloPrice * $buffaloQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $buffalo . '</div>';
			echo '<div class="menu-Quanty"> x' . $buffaloQuantity . '</div>';
			echo '<div class="menu-price">₱' . number_format($buffaloPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $buffaloQuantity;
			$total = $total + ($buffaloPrice * $buffaloQuantity);
		}
		

		
		if (isset($_GET['cheesetoastie'])){
			$cheesetoastie = $_GET['cheesetoastie'];
			$cheesetoastiePrice = $_GET['cheesetoastiePrice'];
			$cheesetoastieQuantity = $_GET['cheesetoastieQuantity'];			
			$totalcheesetoastiefaloPrice = $cheesetoastiePrice * $cheesetoastieQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $cheesetoastie . '</div>';
			echo '<div class="menu-Quanty"> x' . $cheesetoastieQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($cheesetoastiePrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $cheesetoastieQuantity;
			$total = $total + ($cheesetoastiePrice * $cheesetoastieQuantity);
		}

		if (isset($_GET['garlicshrimp'])){
			$garlicshrimp = $_GET['garlicshrimp'];
			$garlicshrimpPrice = $_GET['garlicshrimpPrice'];
			$garlicshrimpQuantity = $_GET['garlicshrimpQuantity'];
			$totalgarlicshrimpPrice = $garlicshrimpPrice * $garlicshrimpQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $garlicshrimp . '</div>';
			echo '<div class="menu-Quanty"> x' . $garlicshrimpQuantity . '</div>';				
			echo '<div class="menu-price">₱' . number_format($garlicshrimpPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $garlicshrimpQuantity;
			$total = $total + $totalgarlicshrimpPrice;
		}

		if (isset($_GET['familyfries'])){
			$familyfries = $_GET['familyfries'];
			$familyfriesPrice = $_GET['familyfriesPrice'];
			$familyfriesQuantity = $_GET['familyfriesQuantity'];
			$totalfamilyfriesPrice = $familyfriesPrice * $familyfriesQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $familyfries . '</div>';
			echo '<div class="menu-Quanty"> x' . $familyfriesQuantity . '</div>';				
			echo '<div class="menu-price">₱' . number_format($familyfriesPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $familyfriesQuantity;
			$total = $total + $totalfamilyfriesPrice;
		}

		if (isset($_GET['hungarianhotdog'])){
			$hungarianhotdog = $_GET['hungarianhotdog'];
			$hungarianhotdogPrice = $_GET['hungarianhotdogPrice'];
			$hungarianhotdogQuantity = $_GET['hungarianhotdogQuantity'];			
			$totalgarlicshrimpPrice = $garlicshrimpPrice * $garlicshrimpQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $hungarianhotdog . '</div>';
			echo '<div class="menu-Quanty"> x' . $hungarianhotdogQuantity . '</div>';				
			echo '<div class="menu-price">₱' . number_format($hungarianhotdogPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $garlicshrimpQuantity;
			$total = $total + $totalgarlicshrimpPrice;
		}

		



		if (isset($_GET['chocoespresso'])){
			$chocoespresso = $_GET['chocoespresso'];
			$chocoespressoPrice = $_GET['chocoespressoPrice'];
			$chocoespressoQuantity = $_GET['chocoespressoQuantity'];
			$totalchocoespressoPrice = $chocoespressoPrice * $chocoespressoQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $chocoespresso . '</div>';
			echo '<div class="menu-Quanty"> x' . $chocoespressoQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($chocoespressoPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $chocoespressoQuantity;
			$total = $total + $totalchocoespressoPrice;
		}

		if (isset($_GET['coldbrew'])){
			$coldbrew = $_GET['coldbrew'];
			$coldbrewPrice = $_GET['coldbrewPrice'];
			$coldbrewQuantity = $_GET['coldbrewQuantity'];
			$totalcoldbrewPrice = $coldbrewPrice * $coldbrewQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $coldbrew . '</div>';
			echo '<div class="menu-Quanty"> x' . $coldbrewQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($coldbrewPrice, 2) . '</div>';
			echo '</div>';

			$totalQuantity = $totalQuantity + $coldbrewQuantity;
			$total = $total + $totalcoldbrewPrice;
		}

		if (isset($_GET['darkfrapp'])){
			$darkfrapp = $_GET['darkfrapp'];
			$darkfrappPrice = $_GET['darkfrappPrice'];
			$darkfrappQuantity = $_GET['darkfrappQuantity'];
			$totaldarkfrappPrice = $darkfrappPrice * $darkfrappQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $darkfrapp . '</div>';
			echo '<div class="menu-Quanty"> x' . $darkfrappQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($darkfrappPrice, 2) . '</div>';
			echo '</div>';
			$totalQuantity = $totalQuantity + $darkfrappQuantity;
			$total = $total + $totaldarkfrappPrice;
		}

		if (isset($_GET['strawberrysmoothie'])){
			$strawberrysmoothie = $_GET['strawberrysmoothie'];
			$strawberrysmoothiePrice = $_GET['strawberrysmoothiePrice'];
			$strawberrysmoothieQuantity = $_GET['strawberrysmoothieQuantity'];
			$totalstrawberrysmoothiePrice = $strawberrysmoothiePrice * $strawberrysmoothieQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $strawberrysmoothie . '</div>';
			echo '<div class="menu-Quanty"> x' . $strawberrysmoothieQuantity . '</div>';				
			echo '<div class="menu-price">₱' . number_format($strawberrysmoothiePrice, 2) . '</div>';
			echo '</div>';
            $totalQuantity = $totalQuantity + $strawberrysmoothieQuantity;
            $total = $total + $totalstrawberrysmoothiePrice;
		}

		if (isset($_GET['vanillamilk'])){
			$vanillamilk = $_GET['vanillamilk'];
			$vanillamilkPrice = $_GET['vanillamilkPrice'];
			$vanillamilkQuantity = $_GET['vanillamilkQuantity'];
			$totalvanillamilkPrice = $vanillamilkPrice * $vanillamilkQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $vanillamilk . '</div>';
			echo '<div class="menu-Quanty"> x' . $vanillamilkQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($vanillamilkPrice, 2) . '</div>';
			echo '</div>';
            $totalQuantity = $totalQuantity + $vanillamilkQuantity;
            $total = $total + $totalvanillamilkPrice;
		}

		if (isset($_GET['matchatea'])){
			$matchatea = $_GET['matchatea'];
			$matchateaPrice = $_GET['matchateaPrice'];
			$matchateaQuantity = $_GET['matchateaQuantity'];
			$totalmatchateaPrice = $matchateaPrice * $matchateaQuantity;
			echo '<div class="ItemContent">';
			echo '<div class="menu-item">' . $matchatea . '</div>';
			echo '<div class="menu-Quanty"> x' . $matchateaQuantity . '</div>';			
			echo '<div class="menu-price">₱' . number_format($matchateaPrice, 2) . '</div>';
			echo '</div>';

            $totalQuantity = $totalQuantity + $matchateaQuantity;
            $total = $total + $totalmatchateaPrice;
		}




	?>
	
	<?php
	if( $total <= 0){
		echo "NO ORDER <br>";
	}
	else{
		echo "<br>";		
		echo "Total Quantity: ";
		echo $totalQuantity;
		echo " &nbsp; Total: &nbsp; ₱";
		echo number_format($total,2);
		echo "<br>";
		
	}

	?>
		
		</h3>

		</div>
		

		<div>
		<input type="text" name="cash" size="15" value="<?php echo $total?>" id="cash">				
		<input type="button"  value="COMPUTE" onclick="FUNCTION(this.value)" style="background-color: #333; color: white;">
		<input type="button" value="CLEAR" onclick="FUNCTION(this.value)" style="background-color: #333; color: white;">
			<div id="computation">

			</div>

			<div id="menu" style="display:none">
			   <a href= "OrderPage3.php" id="OrderAgain" >Order Again</a>
			</div>
		</div>
	<br>
	<hr class="hrSize">


	</div>


<div class="bottom-bar">
    Malabanan Cafe &#174; | 2023
</div>



</body>
</html>




<script>

 function OrderAgain(){
    
 }

 function FUNCTION(action){
    if(action == "COMPUTE"){
        var cash = document.getElementById("cash").value;
        var total = <?php echo $total ?>;



        var computation = cash - total;
        if(computation > 0 ){
            document.getElementById("computation").innerHTML = "Change: ₱" +computation  + " Thank you mwah";
            var menu = document.getElementById("menu");
            menu.style.display = "block";
        }
        else if( computation == 0){
            document.getElementById("computation").innerHTML = "Thank you mwah ";
            var menu = document.getElementById("menu");
            menu.style.display = "block";
        }
        else{
            var computation = total - cash;
            console.log(computation);
            document.getElementById("computation").innerHTML = "Inssufisyent balance :₱ "+computation;
        }
        
    }
    else if(action == "CLEAR"){
        document.getElementById("cash").value = "";
    }

 }

</script>

