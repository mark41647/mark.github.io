<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtmll/DTD/xhtmll-transitional.dtd">
<html lang="en">    
<head>
    <?php 
    session_start();

    if(empty($_SESSION['userName'])){
        ?>
            <script>
                alert("PLEASE LOG IN FIRST!");
                window.location.href = "LoginPage1.php";
            </script>
        <?php
    }
	?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="orderStyle.css">
    <title>Malabanan Cafe</title>
    <link rel="icon" href="caf3.png">
</head>
<body>
    <div id="Order">  

    </div>
    <header>
        <nav>
            <div class="header">
                <img src="caf3.png" class = 'logo'>
                <p class = "title1" id="Top"><a href="#Title1">Malabanan Cafe</a></p>
            </div>

            <div class="user">
                <a href="#"><?php echo $_SESSION['userName']; ?></a>
                <a href="Cartpage4.php">Cart</a>      

           
                <?php
if (isset($_GET['logout'])) {
    $_SESSION = array();

    session_destroy();
    header("Location: LoginPage1.php");
    exit();
}
?>
<?php
    if (isset($_SESSION['userName'])) {
        echo "<a href='?logout=1'>Logout</a>";
    } else {
        echo "<p>You are not logged in.</p>";
    }
    ?>

            </div>
        </nav>
       
    </header>
    <div class="banner">
            <!-- Placeholder image -->
            <img src="banner4.jpg" alt="Banner">
        </div>
    <div class="main-content">

    <nav class="menuBg"></nav>
       
        <nav class="menu">
        
        
            <ul>
                <li><a href="#Top"><img src="Up.png" style="width: 25px"></a></li>
                <li><h1 style="color: #fff"> Menu</h1></li>
                <hr style="color: #fff">
                <li><a href="#BurgersS">Burgers</a></li>
                <li><a href="#SnacksS">Snacks</a></li>
                <li><a href="#BeveragesS">Beverages</a></li>
                <br/>
                <li><a href="#Bot"><img src="Bot.png" style="width: 25px"></a></li>
                
            </ul>
        </nav>


        <div class="content">
            <form action="Cartpage4.php" method="GET">
            <!-- Content of the clicked menu will be displayed here -->
            <div class="BurgersSection">
                <h1 id="BurgersS" style="text-align: center;"> Burgers </h1>
                <hr class="hrSize">

                <div class="BurgCards">	 
					
					<div class="food-card">
						<img src="Burger1.jpg" alt="Burger">
						<h3>Supreme</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Supreme" value="Supreme">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(193.25, 2);
								echo "<input type=hidden name=supremePrice value='193.25'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="supremeQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>
				
					<div class="food-card">
						<img src="Burger4.jpg" alt="Burger">
						<h3>Champ</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Champ" value="Champ">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(114.50, 2);
								echo "<input type=hidden name=champPrice value='114.50'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="champQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>					
					
					<div class="food-card">
						<img src="Burger5.jpg" alt="Burger">
						<h3>Meaty Overload</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Meaty Overload" value="Meaty Overload">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(88.75, 2);
								echo "<input type=hidden name=meatyPrice value='88.75'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="meatyQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>					

					<div class="food-card">
						<img src="Burger3.jpg" alt="Burger">
						<h3>Hawaiian</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Hawaiian" value="Hawaiian">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(85.25, 2);
								echo "<input type=hidden name=hawaiianPrice value='85.25'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="hawaiianQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>

					<div class="food-card">
						<img src="Burger6.jpg" alt="Burger">
						<h3>Double Cheese</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Double Cheese" value="Double Cheese">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(78.50, 2);
								echo "<input type=hidden name=doublecheesePrice value='78.50'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="doublecheeseQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>


					<div class="food-card">
						<img src="Burger2.jpg" alt="Burger">
						<h3>Veggie Overload</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="Veggie Overload" value="Veggie Overload">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱
								<?php
								echo number_format(75.00, 2);
								echo "<input type=hidden name=veggiePrice value='75'>";
								echo "<br>";
								?>
							</div>					
						</div>
						
						<div class="input-container">
						 <input type="text" value="0" name="veggieQuantity" class="inputText" placeholder="Quantity">
						  <div class="highlight"></div>
						</div>
						
					</div>

                    <hr class="hrSize">

                </div>

                
            </div>
            <div class="SnacksSection">
                <h1  id="SnacksS" style="text-align: center;"> Snacks </h1>
                <hr class="hrSize">

                <div class="BurgCards">


					<div class="food-card">
						<img src="Snack1.jpg" alt="Burger">
						<h3>Buffalo Wings</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="buffalo" value="Buffalo Wings">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(78.25, 2); ?>
								<input type="hidden" name="buffaloPrice" value="78.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="buffaloQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Snack2.jpg" alt="Burger">
						<h3>Cheese Toastie</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="cheesetoastie" value="Cheese Toastie">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(65.50, 2); ?>
								<input type="hidden" name="cheesetoastiePrice" value="65.50">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="cheesetoastieQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Snack3.jpg" alt="Burger">
						<h3>Garlic Shrimp</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="garlicshrimp" value="Garlic Shrimp">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(58.75, 2); ?>
								<input type="hidden" name="garlicshrimpPrice" value="58.75">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="garlicshrimpQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Snack4.jpg" alt="Burger">
						<h3>Family Fries</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="familyfries" value="Family Fries">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(55.25, 2); ?>
								<input type="hidden" name="familyfriesPrice" value="55.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="familyfriesQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Snack5.jpg" alt="Burger">
						<h3>Hungarian Hotdog</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="hungarianhotdog" value="Hungarian Hotdog">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(48.50, 2); ?>
								<input type="hidden" name="hungarianhotdogPrice" value="48.50">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="hungarianhotdogQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

		                  
                    <hr class="hrSize">
                    
                    
                </div>    
            </div>

            <div class="DrinksSection">
                <h1  id="BeveragesS" style="text-align: center;"> Beverages </h1>
                <hr class="hrSize">

                <div class="BurgCards">
                    

					<div class="food-card">
						<img src="Drink1.jpg" alt="Burger">
						<h3>Choco Espresso</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="chocoespresso" value="Choco Espresso">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(75.25, 2); ?>
								<input type="hidden" name="chocoespressoPrice" value="75.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="chocoespressoQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Drink2.jpg" alt="Burger">
						<h3>Cold Brew Caramel</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="coldbrew" value="Cold Brew Caramel">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(75.50, 2); ?>
								<input type="hidden" name="coldbrewPrice" value="75.50">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="coldbrewQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Drink3.jpg" alt="Burger">
						<h3>Dark Frappuccino</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="darkfrapp" value="Dark Frappuccino">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(70.25, 2); ?>
								<input type="hidden" name="darkfrappPrice" value="70.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="darkfrappQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Drink4.jpg" alt="Burger">
						<h3>Strawberry Smoothie</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="strawberrysmoothie" value="Strawberry Smoothie">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(65.25, 2); ?>
								<input type="hidden" name="strawberrysmoothiePrice" value="65.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="strawberrysmoothieQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Drink5.jpg" alt="Burger">
						<h3>Vanilla Milk Tea</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="vanillamilk" value="Vanilla Milk Tea">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(55.25, 2); ?>
								<input type="hidden" name="vanillamilkPrice" value="55.25">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="vanillamilkQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

					<div class="food-card">
						<img src="Drink6.jpg" alt="Burger">
						<h3>Matcha Tea Latte</h3>
						<div class="checkbox-price-container">
							<label class="container">
								<input type="checkbox" name="matchatea" value="Matcha Tea Latte">
								<div class="checkmark"></div>
							</label>
							<div class="price-container">
								Price: ₱ <?php echo number_format(58.50, 2); ?>
								<input type="hidden" name="matchateaPrice" value="58.50">
								<br>
							</div>
						</div>

						<div class="input-container">
							<input type="text" value="0" name="matchateaQuantity" class="inputText" placeholder="Quantity">
							<div class="highlight"></div>
						</div>
					</div>

                    
                    
                    
                    <hr class="hrSize">
                
                </div>    
            </div>

            <hr class="BotLine" id="Bot">

        
        </div>
        


    </div>

	<div class="cart">
		<div class="cart-info">
            <span id="cartTotal">Total quantity in the cart: 0 </span>
                <div class ="ViewOrderButton">
                    <button type="submit">Checkout</button>
                </div>
        </div>
    </div>
	
    </form>
</body>
</html>

<script>
document.addEventListener("DOMContentLoaded", function () {
    // Get all checkbox elements
    const checkboxes = document.querySelectorAll("input[type='checkbox']");
    const quantityInputs = document.querySelectorAll(".inputText");
    const cartInfo = document.getElementById("cartTotal");

    // Function to update the cart total quantity
    function updateCartTotal() {
        let cartTotalQuantity = 0;

        checkboxes.forEach((checkbox, index) => {
            if (checkbox.checked) {
                const quantityValue = parseInt(quantityInputs[index].value) || 0;
                cartTotalQuantity += quantityValue;
            }
        });

        updateCartInfo(cartTotalQuantity);
    }

    // Add event listeners for the checkboxes
    checkboxes.forEach((checkbox, index) => {
        checkbox.addEventListener("change", function () {
            updateCartTotal();
        });
    });

    // Add event listeners for the quantity inputs
    quantityInputs.forEach((input, index) => {
        input.addEventListener("input", function () {
            const quantityValue = parseInt(input.value) || 0;
            const checkbox = checkboxes[index];

            // Update the cart total quantity only if the item is checked
            if (checkbox.checked) {
                updateCartTotal();
            }
        });
    });

    // Function to update the cart info text
    function updateCartInfo(cartTotalQuantity) {
        cartInfo.textContent = `Total quantity in the cart: ${cartTotalQuantity}`;
    }
});
</script>
