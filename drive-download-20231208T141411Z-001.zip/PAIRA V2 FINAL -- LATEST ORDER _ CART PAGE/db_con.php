<?Php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "db_cafe";


$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);
if (!$conn){
	die(" wrong; ");
}

	
?>